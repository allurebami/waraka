const WHATSAPP_NUMBER = "237657806397";
let practitioners = [];
let products = (window.WARAKA_PRODUCTS || []).map((p) => ({ ...p, isDemo: true }));
let tips = (window.WARAKA_TIPS || []).map((t) => ({ ...t, isDemo: true }));
const demoPractitioners = (window.WARAKA_PRACTITIONERS || []).map((person) => ({ ...person, isDemo: true }));
const dataService = window.WARAKA_DATA;
const searchInput = document.querySelector("#practitionerSearch");
const cityFilter = document.querySelector("#practitionerCity");
const catalog = document.querySelector("#practitionerCatalog");
const count = document.querySelector("#practitionerCount");
const emptyState = document.querySelector("#practitionerCatalogEmpty");
const sourceNote = document.querySelector("#practitionerSourceNote");
const dialog = document.querySelector("#practitionerDialog");
const dialogContent = document.querySelector("#practitionerDialogContent");

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[character]);
}

function normalize(value) {
  return String(value ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}

function practitionerCard(person) {
  const image = person.image || "assets/waraka-apercu.jpg";
  const status = person.isDemo ? "Profil fictif" : "Profil publié";
  const linkedProducts = products.filter((prod) => prod.practitionerId === person.id || (prod.practitionerName && normalize(prod.practitionerName) === normalize(person.name)));
  const productCountLabel = linkedProducts.length > 0
    ? `<span class="practitioner-products-tag">${linkedProducts.length} produit${linkedProducts.length > 1 ? "s" : ""} référencé${linkedProducts.length > 1 ? "s" : ""}</span>`
    : "";

  return `
    <article class="directory-card practitioner-card">
      <div class="card-media practitioner-media">
        <img src="${escapeHTML(image)}" alt="${escapeHTML(person.imageAlt || person.name)}" loading="lazy" />
        <span class="demo-badge">${status}</span>
      </div>
      <div class="card-body">
        <div class="card-meta"><span>${escapeHTML(person.city)}</span><span>${person.isDemo ? "À vérifier" : "Référencé par WARAKA"}</span></div>
        <h3>${escapeHTML(person.name)}</h3>
        <p>${escapeHTML(person.specialty)}</p>
        ${productCountLabel}
        <button class="text-button" type="button" data-practitioner-detail="${escapeHTML(person.id)}">Voir le profil &amp; ses produits <span aria-hidden="true">→</span></button>
      </div>
    </article>`;
}

function updateCityOptions() {
  const selected = cityFilter.value;
  const cities = [...new Set(practitioners.map((person) => person.city).filter(Boolean))].sort((a, b) => a.localeCompare(b, "fr"));
  cityFilter.innerHTML = '<option value="all">Toutes les villes</option>' + cities
    .map((city) => `<option value="${escapeHTML(city)}">${escapeHTML(city)}</option>`).join("");
  cityFilter.value = cities.includes(selected) ? selected : "all";
}

function render() {
  const query = normalize(searchInput.value);
  const selectedCity = cityFilter.value;
  const visible = practitioners.filter((person) => {
    const cityMatches = selectedCity === "all" || person.city === selectedCity;
    const queryMatches = !query || normalize(`${person.name} ${person.specialty} ${person.city} ${person.region}`).includes(query);
    return cityMatches && queryMatches;
  });
  catalog.innerHTML = visible.map(practitionerCard).join("");
  count.textContent = `${visible.length} profil${visible.length === 1 ? "" : "s"}`;
  emptyState.hidden = visible.length > 0;
}

function openDetails(id) {
  const person = practitioners.find((entry) => entry.id === id);
  if (!person) return;
  const image = person.image || "assets/waraka-apercu.jpg";
  const linkedProducts = products.filter((prod) => prod.practitionerId === person.id || (prod.practitionerName && normalize(prod.practitionerName) === normalize(person.name)));
  const linkedTips = tips.filter((tip) => tip.practitionerId === person.id || (tip.practitionerName && normalize(tip.practitionerName) === normalize(person.name)));

  const productsHtml = linkedProducts.length > 0 ? `
    <div class="dialog-related-section">
      <p class="eyebrow">PRODUITS ASSOCIÉS (${linkedProducts.length})</p>
      <div class="dialog-related-list">
        ${linkedProducts.map((prod) => `
          <button class="dialog-related-item" type="button" data-product-detail="${escapeHTML(prod.id)}">
            <img src="${escapeHTML(prod.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(prod.name)}" />
            <span>
              <strong>${escapeHTML(prod.name)}</strong>
              <small>${escapeHTML(prod.categoryLabel)}</small>
            </span>
            <span aria-hidden="true">→</span>
          </button>`).join("")}
      </div>
    </div>` : "";

  const tipsHtml = linkedTips.length > 0 ? `
    <div class="dialog-related-section">
      <p class="eyebrow">ASTUCES PARTAGÉES (${linkedTips.length})</p>
      <div class="dialog-related-list">
        ${linkedTips.map((tip) => `
          <a class="dialog-related-item" href="astuces.html">
            <img src="${escapeHTML(tip.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(tip.title)}" />
            <span>
              <strong>${escapeHTML(tip.title)}</strong>
              <small>${escapeHTML(tip.plantFocus)}</small>
            </span>
            <span aria-hidden="true">→</span>
          </a>`).join("")}
      </div>
    </div>` : "";

  const whatsappText = encodeURIComponent(`Bonjour WARAKA, je souhaite entrer en contact avec ${person.name} (${person.city}).`);

  dialogContent.innerHTML = `
    <img class="dialog-image" src="${escapeHTML(image)}" alt="${escapeHTML(person.imageAlt || person.name)}" />
    <p class="eyebrow">PROFIL PRATICIEN · ${person.isDemo ? "DÉMONSTRATION" : "WARAKA"}</p>
    <h2 id="dialogTitle">${escapeHTML(person.name)}</h2>
    <p class="dialog-summary">${escapeHTML(person.specialty)} · ${escapeHTML(person.city)}</p>
    <p>${escapeHTML(person.details || "")}</p>
    ${productsHtml}
    ${tipsHtml}
    <div class="dialog-actions">
      <a class="button button-primary" href="https://wa.me/${WHATSAPP_NUMBER}?text=${whatsappText}" target="_blank" rel="noreferrer">Contacter via WARAKA (WhatsApp)</a>
    </div>
    <p class="dialog-disclaimer">Le référencement ne vaut pas autorisation d’exercice et ne constitue pas une recommandation médicale.</p>`;
  dialog.showModal();
}

function openProductDetails(id) {
  const product = products.find((item) => item.id === id);
  if (!product) return;
  dialogContent.innerHTML = `
    <img class="dialog-image" src="${escapeHTML(product.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(product.imageAlt || product.name)}" />
    <p class="eyebrow">FICHE PRODUIT · ${product.isDemo ? "DÉMONSTRATION" : "WARAKA"}</p>
    <h2 id="dialogTitle">${escapeHTML(product.name)}</h2>
    <p class="dialog-summary">${escapeHTML(product.categoryLabel)}${product.practitionerName ? ` · ${escapeHTML(product.practitionerName)}` : ""}</p>
    <p>${escapeHTML(product.details || "")}</p>
    ${product.practitionerId ? `<div class="dialog-actions"><button class="button button-primary" type="button" data-practitioner-detail="${escapeHTML(product.practitionerId)}">← Retour au profil du praticien</button></div>` : ""}
    <p class="dialog-disclaimer">Cette fiche documentaire ne constitue ni une certification ni une recommandation médicale.</p>`;
  dialog.showModal();
}

searchInput.addEventListener("input", render);
cityFilter.addEventListener("change", render);
document.querySelector("#practitionerSearchButton").addEventListener("click", render);
document.addEventListener("click", (event) => {
  const trigger = event.target.closest("[data-practitioner-detail]");
  if (trigger) {
    openDetails(trigger.dataset.practitionerDetail);
    return;
  }
  const prodTrigger = event.target.closest("[data-product-detail]");
  if (prodTrigger) {
    openProductDetails(prodTrigger.dataset.productDetail);
  }
});
document.querySelector("#practitionerDialogClose").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", (event) => {
  if (event.target === dialog) dialog.close();
});

async function loadPractitioners() {
  if (!dataService?.isConfigured()) {
    practitioners = demoPractitioners;
    updateCityOptions();
    render();
    return;
  }

  sourceNote.hidden = false;
  sourceNote.textContent = "Chargement des profils WARAKA…";
  try {
    const results = await Promise.allSettled([
      dataService.listPractitioners(),
      dataService.listProducts(),
      dataService.listTips(),
    ]);
    practitioners = results[0].status === "fulfilled" ? results[0].value : [];
    if (results[1].status === "fulfilled") products = results[1].value;
    if (results[2].status === "fulfilled") tips = results[2].value;

    updateCityOptions();
    sourceNote.textContent = "Seuls les profils publiés par WARAKA apparaissent dans cet annuaire.";
    render();
  } catch (error) {
    console.error("Impossible de charger l’annuaire WARAKA.", error);
    practitioners = [];
    catalog.innerHTML = "";
    count.textContent = "0 profil";
    sourceNote.textContent = "L’annuaire est momentanément indisponible. Réessayez dans quelques instants.";
    emptyState.textContent = "Impossible de charger les profils. Vérifiez la connexion ou réessayez plus tard.";
    emptyState.hidden = false;
  }
}

loadPractitioners();
