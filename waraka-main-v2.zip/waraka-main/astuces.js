let tips = [];
let practitioners = (window.WARAKA_PRACTITIONERS || []).map((p) => ({ ...p, isDemo: true }));
let products = (window.WARAKA_PRODUCTS || []).map((p) => ({ ...p, isDemo: true }));
const demoTips = (window.WARAKA_TIPS || []).map((t) => ({ ...t, isDemo: true }));
const dataService = window.WARAKA_DATA;

const searchInput = document.querySelector("#tipSearch");
const catalogList = document.querySelector("#tipsCatalogList");
const catalogCount = document.querySelector("#tipsCatalogCount");
const catalogEmpty = document.querySelector("#tipsCatalogEmpty");
const sourceNote = document.querySelector("#tipsSourceNote");
const dialog = document.querySelector("#tipDialog");
const dialogContent = document.querySelector("#dialogContent");
let activeCategory = "all";

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[character]);
}

function normalize(value) {
  return String(value ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}

function getLinkedPractitioner(tip) {
  if (tip.practitionerId) {
    const found = practitioners.find((p) => p.id === tip.practitionerId);
    if (found) return found;
  }
  if (tip.practitionerName) {
    const found = practitioners.find((p) => normalize(p.name) === normalize(tip.practitionerName));
    if (found) return found;
  }
  return null;
}

function tipCard(tip) {
  const linked = getLinkedPractitioner(tip);
  const pName = linked?.name || tip.practitionerName;
  const pImage = linked?.image || tip.practitionerImage || "assets/waraka-apercu.jpg";
  const pId = linked?.id || tip.practitionerId;

  const authorBadge = pName
    ? `<div class="linked-practitioner-box">
        <img class="linked-practitioner-avatar" src="${escapeHTML(pImage)}" alt="${escapeHTML(pName)}" loading="lazy" />
        <div class="linked-practitioner-info">
          <span class="linked-label">Astuce partagée par</span>
          ${pId
            ? `<button class="linked-practitioner-link" type="button" data-practitioner-detail="${escapeHTML(pId)}">${escapeHTML(pName)}</button>`
            : `<span class="linked-practitioner-name">${escapeHTML(pName)}</span>`
          }
        </div>
      </div>`
    : "";

  return `
    <article class="directory-card tip-card">
      <div class="card-media">
        <img src="${escapeHTML(tip.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(tip.imageAlt || tip.title)}" loading="lazy" />
        <span class="demo-badge">${escapeHTML(tip.categoryLabel)}</span>
      </div>
      <div class="card-body">
        <div class="card-meta"><span>${escapeHTML(tip.plantFocus)}</span><span>${tip.isDemo ? "Exemple" : "Conseil vérifié"}</span></div>
        <h3>${escapeHTML(tip.title)}</h3>
        <p>${escapeHTML(tip.summary)}</p>
        ${authorBadge}
        <button class="text-button" type="button" data-tip-detail="${escapeHTML(tip.id)}">Lire l’astuce complète <span aria-hidden="true">→</span></button>
      </div>
    </article>`;
}

function render() {
  const query = normalize(searchInput.value);
  const visible = tips.filter((tip) => {
    const categoryMatches = activeCategory === "all" || tip.category === activeCategory;
    const queryMatches = !query || normalize(`${tip.title} ${tip.categoryLabel} ${tip.plantFocus} ${tip.summary} ${tip.practitionerName}`).includes(query);
    return categoryMatches && queryMatches;
  });
  catalogList.innerHTML = visible.map(tipCard).join("");
  catalogCount.textContent = `${visible.length} astuce${visible.length === 1 ? "" : "s"}`;
  catalogEmpty.hidden = visible.length > 0;
}

function openTipDetails(id) {
  const tip = tips.find((item) => item.id === id);
  if (!tip) return;
  const linked = getLinkedPractitioner(tip);
  const pName = linked?.name || tip.practitionerName;
  const pImage = linked?.image || tip.practitionerImage || "assets/waraka-apercu.jpg";
  const pId = linked?.id || tip.practitionerId;
  const linkedProduct = tip.productId ? products.find((p) => p.id === tip.productId) : null;

  const practitionerSection = pName ? `
    <div class="dialog-linked-card">
      <img src="${escapeHTML(pImage)}" alt="${escapeHTML(pName)}" />
      <div>
        <span class="linked-label">PARTAGÉ PAR</span>
        <strong>${escapeHTML(pName)}</strong>
        <small>${escapeHTML(tip.plantFocus)}</small>
      </div>
      ${pId ? `<button class="button button-primary" type="button" data-practitioner-detail="${escapeHTML(pId)}">Voir le praticien</button>` : ""}
    </div>` : "";

  const productSection = linkedProduct ? `
    <div class="dialog-related-section">
      <p class="eyebrow">PRODUIT ASSOCIÉ À CETTE ASTUCE</p>
      <div class="dialog-related-list">
        <a class="dialog-related-item" href="produits.html">
          <img src="${escapeHTML(linkedProduct.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(linkedProduct.name)}" />
          <span>
            <strong>${escapeHTML(linkedProduct.name)}</strong>
            <small>${escapeHTML(linkedProduct.categoryLabel)}</small>
          </span>
          <span aria-hidden="true">→</span>
        </a>
      </div>
    </div>` : "";

  dialogContent.innerHTML = `
    <img class="dialog-image" src="${escapeHTML(tip.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(tip.imageAlt || tip.title)}" />
    <p class="eyebrow">ASTUCE &amp; SAVOIR · ${escapeHTML(tip.categoryLabel)}</p>
    <h2 id="dialogTitle">${escapeHTML(tip.title)}</h2>
    <p class="dialog-summary">${escapeHTML(tip.plantFocus)}</p>
    <p>${escapeHTML(tip.content || tip.summary)}</p>
    ${practitionerSection}
    ${productSection}
    <p class="dialog-disclaimer">Information éducative. Ne remplace pas l’avis d’un professionnel de santé.</p>`;
  dialog.showModal();
}

function openPractitionerDetails(id) {
  const person = practitioners.find((item) => item.id === id);
  if (!person) return;
  dialogContent.innerHTML = `
    <img class="dialog-image" src="${escapeHTML(person.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(person.imageAlt || person.name)}" />
    <p class="eyebrow">PROFIL PRATICIEN · ${person.isDemo ? "DÉMONSTRATION" : "WARAKA"}</p>
    <h2 id="dialogTitle">${escapeHTML(person.name)}</h2>
    <p class="dialog-summary">${escapeHTML(person.specialty)} · ${escapeHTML(person.city)}</p>
    <p>${escapeHTML(person.details || "")}</p>
    <div class="dialog-actions">
      <a class="button button-primary" href="praticiens.html">Voir tous les praticiens</a>
    </div>
    <p class="dialog-disclaimer">Le référencement ne vaut pas autorisation d’exercice et ne constitue pas une recommandation médicale.</p>`;
  dialog.showModal();
}

document.querySelectorAll("[data-tip-category]").forEach((button) => {
  button.addEventListener("click", () => {
    activeCategory = button.dataset.tipCategory;
    document.querySelectorAll("[data-tip-category]").forEach((chip) => {
      const active = chip === button;
      chip.classList.toggle("is-active", active);
      chip.setAttribute("aria-pressed", String(active));
    });
    render();
  });
});

searchInput.addEventListener("input", render);
document.querySelector("#tipSearchButton").addEventListener("click", render);
document.addEventListener("click", (event) => {
  const tipTrigger = event.target.closest("[data-tip-detail]");
  if (tipTrigger) {
    openTipDetails(tipTrigger.dataset.tipDetail);
    return;
  }
  const pracTrigger = event.target.closest("[data-practitioner-detail]");
  if (pracTrigger) {
    openPractitionerDetails(pracTrigger.dataset.practitionerDetail);
  }
});
document.querySelector("#dialogClose").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", (event) => {
  if (event.target === dialog) dialog.close();
});

async function loadTips() {
  if (!dataService?.isConfigured()) {
    tips = demoTips;
    render();
    return;
  }

  sourceNote.textContent = "Chargement des astuces WARAKA…";
  try {
    const results = await Promise.allSettled([
      dataService.listTips(),
      dataService.listPractitioners(),
      dataService.listProducts(),
    ]);
    if (results[0].status === "fulfilled" && Array.isArray(results[0].value)) {
      tips = results[0].value;
      sourceNote.textContent = "Conseils et savoirs partagés par les praticiens référencés sur WARAKA.";
    } else {
      tips = demoTips;
      sourceNote.textContent = "Exemples d'astuces (exécutez la mise à jour schema.sql dans Supabase pour activer les astuces dynamiques).";
    }
    if (results[1].status === "fulfilled") practitioners = results[1].value;
    if (results[2].status === "fulfilled") products = results[2].value;
    render();
  } catch (error) {
    console.error("Impossible de charger les astuces WARAKA.", error);
    tips = demoTips;
    render();
  }
}

loadTips();
