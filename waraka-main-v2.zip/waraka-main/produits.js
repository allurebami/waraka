const WHATSAPP_NUMBER = "237657806397";
let products = [];
let practitioners = (window.WARAKA_PRACTITIONERS || []).map((p) => ({ ...p, isDemo: true }));
const demoProducts = (window.WARAKA_PRODUCTS || []).map((product) => ({ ...product, isDemo: true }));
const dataService = window.WARAKA_DATA;
const searchInput = document.querySelector("#productSearch");
const catalogList = document.querySelector("#catalogList");
const catalogCount = document.querySelector("#catalogCount");
const catalogEmpty = document.querySelector("#catalogEmpty");
const sourceNote = document.querySelector("#catalogSourceNote");
const dialog = document.querySelector("#productDialog");
const dialogContent = document.querySelector("#dialogContent");
let activeCategory = "all";

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[character]);
}

function normalize(value) {
  return String(value ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}

function getLinkedPractitioner(product) {
  if (product.practitionerId) {
    const found = practitioners.find((p) => p.id === product.practitionerId);
    if (found) return found;
  }
  if (product.practitionerName) {
    const found = practitioners.find((p) => normalize(p.name) === normalize(product.practitionerName));
    if (found) return found;
  }
  return null;
}

function productCard(product) {
  const badge = product.isDemo
    ? "Démonstration"
    : product.isFeatured ? "Mis en avant par WARAKA" : "Référencement validé";
  const image = product.image || "assets/waraka-apercu.jpg";
  const linked = getLinkedPractitioner(product);
  const pName = linked?.name || product.practitionerName;
  const pCity = linked?.city || product.practitionerCity;
  const pImage = linked?.image || product.practitionerImage || "assets/waraka-apercu.jpg";
  const pId = linked?.id || product.practitionerId;

  const practitionerPill = pName
    ? `<div class="linked-practitioner-box">
        <img class="linked-practitioner-avatar" src="${escapeHTML(pImage)}" alt="${escapeHTML(pName)}" loading="lazy" />
        <div class="linked-practitioner-info">
          <span class="linked-label">Proposé par</span>
          ${pId
            ? `<button class="linked-practitioner-link" type="button" data-practitioner-detail="${escapeHTML(pId)}">${escapeHTML(pName)}${pCity ? ` · ${escapeHTML(pCity)}` : ""}</button>`
            : `<span class="linked-practitioner-name">${escapeHTML(pName)}${pCity ? ` · ${escapeHTML(pCity)}` : ""}</span>`
          }
        </div>
      </div>`
    : "";

  return `
    <article class="directory-card">
      <div class="card-media">
        <img src="${escapeHTML(image)}" alt="${escapeHTML(product.imageAlt || product.name)}" loading="lazy" />
        <span class="demo-badge">${escapeHTML(badge)}</span>
      </div>
      <div class="card-body">
        <div class="card-meta"><span>${escapeHTML(product.categoryLabel)}</span><span>${product.isDemo ? "Information indicative" : "Fiche documentaire"}</span></div>
        <h3>${escapeHTML(product.name)}</h3>
        <p>${escapeHTML(product.description)}</p>
        ${practitionerPill}
        <button class="text-button" type="button" data-product-detail="${escapeHTML(product.id)}">Consulter la fiche <span aria-hidden="true">→</span></button>
      </div>
    </article>`;
}

function render() {
  const query = normalize(searchInput.value);
  const visible = products.filter((product) => {
    const categoryMatches = activeCategory === "all" || product.category === activeCategory;
    const queryMatches = !query || normalize(`${product.name} ${product.categoryLabel} ${product.description} ${product.practitionerName} ${product.practitionerCity}`).includes(query);
    return categoryMatches && queryMatches;
  });
  catalogList.innerHTML = visible.map(productCard).join("");
  catalogCount.textContent = `${visible.length} fiche${visible.length === 1 ? "" : "s"}`;
  catalogEmpty.hidden = visible.length > 0;
  if (!visible.length && dataService?.isConfigured()) {
    catalogEmpty.textContent = "Aucun produit validé ne correspond à cette recherche.";
  }
}

function openProductDetails(id) {
  const product = products.find((item) => item.id === id);
  if (!product) return;
  const isDemo = Boolean(product.isDemo);
  const linked = getLinkedPractitioner(product);
  const pName = linked?.name || product.practitionerName;
  const pCity = linked?.city || product.practitionerCity;
  const pImage = linked?.image || product.practitionerImage || "assets/waraka-apercu.jpg";
  const pId = linked?.id || product.practitionerId;
  const whatsappText = encodeURIComponent(`Bonjour WARAKA, je souhaite avoir plus d'informations sur le produit "${product.name}"${pName ? ` proposé par ${pName}` : ""}.`);

  const practitionerSection = pName ? `
    <div class="dialog-linked-card">
      <img src="${escapeHTML(pImage)}" alt="${escapeHTML(pName)}" />
      <div>
        <span class="linked-label">PRATICIEN RÉFÉRENT</span>
        <strong>${escapeHTML(pName)}</strong>
        ${pCity ? `<small>${escapeHTML(pCity)}</small>` : ""}
      </div>
      ${pId ? `<button class="button button-primary" type="button" data-practitioner-detail="${escapeHTML(pId)}">Voir son profil</button>` : ""}
    </div>` : "";

  dialogContent.innerHTML = `
    <img class="dialog-image" src="${escapeHTML(product.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(product.imageAlt || product.name)}" />
    <p class="eyebrow">FICHE PRODUIT · ${isDemo ? "DÉMONSTRATION" : "RÉFÉRENCEMENT WARAKA"}</p>
    <h2 id="dialogTitle">${escapeHTML(product.name)}</h2>
    <p class="dialog-summary">${escapeHTML(product.categoryLabel)}${pName ? ` · ${escapeHTML(pName)}` : ""}</p>
    <p>${escapeHTML(product.details)}</p>
    ${practitionerSection}
    <div class="dialog-actions">
      <a class="button button-primary" href="https://wa.me/${WHATSAPP_NUMBER}?text=${whatsappText}" target="_blank" rel="noreferrer">Demander des renseignements sur WhatsApp</a>
    </div>
    <p class="dialog-disclaimer">Cette fiche documentaire ne constitue ni une certification d’efficacité ni un conseil de santé.</p>`;
  dialog.showModal();
}

function openPractitionerDetails(id) {
  const person = practitioners.find((item) => item.id === id);
  if (!person) return;
  const linkedProducts = products.filter((prod) => prod.practitionerId === person.id || (prod.practitionerName && normalize(prod.practitionerName) === normalize(person.name)));
  const productsHtml = linkedProducts.length > 0 ? `
    <div class="dialog-related-section">
      <p class="eyebrow">PRODUITS DE CE PRATICIEN (${linkedProducts.length})</p>
      <div class="dialog-related-list">
        ${linkedProducts.map((prod) => `
          <button class="dialog-related-item" type="button" data-product-detail="${escapeHTML(prod.id)}">
            <img src="${escapeHTML(prod.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(prod.name)}" />
            <span>
              <strong>${escapeHTML(prod.name)}</strong>
              <small>${escapeHTML(prod.categoryLabel)}</small>
            </span>
            <span aria-hidden="true">→</span>
          </button>`).join("")}
      </div>
    </div>` : "";

  dialogContent.innerHTML = `
    <img class="dialog-image" src="${escapeHTML(person.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(person.imageAlt || person.name)}" />
    <p class="eyebrow">PROFIL PRATICIEN · ${person.isDemo ? "DÉMONSTRATION" : "WARAKA"}</p>
    <h2 id="dialogTitle">${escapeHTML(person.name)}</h2>
    <p class="dialog-summary">${escapeHTML(person.specialty)} · ${escapeHTML(person.city)}</p>
    <p>${escapeHTML(person.details || "")}</p>
    ${productsHtml}
    <p class="dialog-disclaimer">Le référencement ne vaut pas autorisation d’exercice et ne constitue pas une recommandation médicale.</p>`;
  dialog.showModal();
}

document.querySelectorAll("[data-product-category]").forEach((button) => {
  button.addEventListener("click", () => {
    activeCategory = button.dataset.productCategory;
    document.querySelectorAll("[data-product-category]").forEach((chip) => {
      const active = chip === button;
      chip.classList.toggle("is-active", active);
      chip.setAttribute("aria-pressed", String(active));
    });
    render();
  });
});

searchInput.addEventListener("input", render);
document.querySelector("#catalogSearchButton").addEventListener("click", render);
document.addEventListener("click", (event) => {
  const prodTrigger = event.target.closest("[data-product-detail]");
  if (prodTrigger) {
    openProductDetails(prodTrigger.dataset.productDetail);
    return;
  }
  const pracTrigger = event.target.closest("[data-practitioner-detail]");
  if (pracTrigger) {
    openPractitionerDetails(pracTrigger.dataset.practitionerDetail);
  }
});
document.querySelector("#dialogClose").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", (event) => {
  if (event.target === dialog) dialog.close();
});

async function loadProducts() {
  if (!dataService?.isConfigured()) {
    products = demoProducts;
    render();
    return;
  }

  sourceNote.textContent = "Chargement du catalogue WARAKA…";
  catalogEmpty.hidden = true;
  try {
    const [loadedProducts, loadedPractitioners] = await Promise.all([
      dataService.listProducts(),
      dataService.listPractitioners(),
    ]);
    products = loadedProducts;
    practitioners = loadedPractitioners;
    sourceNote.textContent = "Les fiches publiées sont issues du catalogue WARAKA et restent soumises à notre démarche documentaire.";
    render();
  } catch (error) {
    console.error("Impossible de charger le catalogue WARAKA.", error);
    products = [];
    sourceNote.textContent = "Le catalogue est momentanément indisponible. Réessayez dans quelques instants.";
    catalogList.innerHTML = "";
    catalogCount.textContent = "0 fiche";
    catalogEmpty.textContent = "Impossible de charger les produits. Vérifiez la connexion ou réessayez plus tard.";
    catalogEmpty.hidden = false;
  }
}

if (dataService?.isConfigured()) sourceNote.hidden = false;
loadProducts();
