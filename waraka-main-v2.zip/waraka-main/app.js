const WHATSAPP_NUMBER = "237657806397";
let products = (window.WARAKA_PRODUCTS || []).map((product) => ({ ...product, isDemo: true }));
let practitioners = (window.WARAKA_PRACTITIONERS || []).map((person) => ({ ...person, isDemo: true }));
let tips = (window.WARAKA_TIPS || []).map((tip) => ({ ...tip, isDemo: true }));
const dataService = window.WARAKA_DATA;

const productList = document.querySelector("#productList");
const practitionerList = document.querySelector("#practitionerList");
const tipList = document.querySelector("#tipList");
const globalSearch = document.querySelector("#globalSearch");
const cityFilter = document.querySelector("#cityFilter");
const productCount = document.querySelector("#productCount");
const tipCount = document.querySelector("#tipCount");
const productEmpty = document.querySelector("#productEmpty");
const practitionerEmpty = document.querySelector("#practitionerEmpty");
const tipEmpty = document.querySelector("#tipEmpty");
const dialog = document.querySelector("#detailDialog");
const dialogContent = document.querySelector("#dialogContent");
let activeCategory = "all";

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[character]);
}

function normalize(value) {
  return String(value ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}

function getLinkedPractitioner(item) {
  if (item.practitionerId) {
    const found = practitioners.find((p) => p.id === item.practitionerId);
    if (found) return found;
  }
  if (item.practitionerName) {
    const found = practitioners.find((p) => normalize(p.name) === normalize(item.practitionerName));
    if (found) return found;
  }
  return null;
}

function productCard(product) {
  const badge = product.isDemo ? "Démonstration" : product.isFeatured ? "Mis en avant par WARAKA" : "Référencement validé";
  const linkedPractitioner = getLinkedPractitioner(product);
  const pName = linkedPractitioner?.name || product.practitionerName;
  const pCity = linkedPractitioner?.city || product.practitionerCity;
  const pImage = linkedPractitioner?.image || product.practitionerImage || "assets/waraka-apercu.jpg";
  const pId = linkedPractitioner?.id || product.practitionerId;

  const practitionerPill = pName
    ? `<div class="linked-practitioner-box">
        <img class="linked-practitioner-avatar" src="${escapeHTML(pImage)}" alt="${escapeHTML(pName)}" loading="lazy" />
        <div class="linked-practitioner-info">
          <span class="linked-label">Proposé par</span>
          ${pId
            ? `<button class="linked-practitioner-link" type="button" data-detail-type="practitioner" data-detail-id="${escapeHTML(pId)}">${escapeHTML(pName)}${pCity ? ` · ${escapeHTML(pCity)}` : ""}</button>`
            : `<span class="linked-practitioner-name">${escapeHTML(pName)}${pCity ? ` · ${escapeHTML(pCity)}` : ""}</span>`
          }
        </div>
      </div>`
    : "";

  return `
    <article class="directory-card">
      <div class="card-media">
        <img src="${escapeHTML(product.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(product.imageAlt || product.name)}" loading="lazy" />
        <span class="demo-badge">${escapeHTML(badge)}</span>
      </div>
      <div class="card-body">
        <div class="card-meta"><span>${escapeHTML(product.categoryLabel)}</span><span>${product.isDemo ? "Information indicative" : "Fiche documentaire"}</span></div>
        <h3>${escapeHTML(product.name)}</h3>
        <p>${escapeHTML(product.description)}</p>
        ${practitionerPill}
        <button class="text-button" type="button" data-detail-type="product" data-detail-id="${escapeHTML(product.id)}">Consulter la fiche <span aria-hidden="true">→</span></button>
      </div>
    </article>`;
}

function practitionerCard(person) {
  const relatedProducts = products.filter((prod) => prod.practitionerId === person.id || (prod.practitionerName && normalize(prod.practitionerName) === normalize(person.name)));
  const productCountLabel = relatedProducts.length > 0
    ? `<span class="practitioner-products-tag">${relatedProducts.length} produit${relatedProducts.length > 1 ? "s" : ""} référencé${relatedProducts.length > 1 ? "s" : ""}</span>`
    : "";

  return `
    <article class="directory-card practitioner-card">
      <div class="card-media practitioner-media">
        <img src="${escapeHTML(person.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(person.imageAlt || person.name)}" loading="lazy" />
        <span class="demo-badge">${person.isDemo ? "Profil fictif" : "Profil publié"}</span>
      </div>
      <div class="card-body">
        <div class="card-meta"><span>${escapeHTML(person.city)}</span><span>${person.isDemo ? "À vérifier" : "Référencé par WARAKA"}</span></div>
        <h3>${escapeHTML(person.name)}</h3>
        <p>${escapeHTML(person.specialty)}</p>
        ${productCountLabel}
        <button class="text-button" type="button" data-detail-type="practitioner" data-detail-id="${escapeHTML(person.id)}">Voir le profil &amp; ses produits <span aria-hidden="true">→</span></button>
      </div>
    </article>`;
}

function tipCard(tip) {
  const linkedPractitioner = getLinkedPractitioner(tip);
  const pName = linkedPractitioner?.name || tip.practitionerName;
  const pImage = linkedPractitioner?.image || tip.practitionerImage || "assets/waraka-apercu.jpg";
  const pId = linkedPractitioner?.id || tip.practitionerId;

  const authorBadge = pName
    ? `<div class="linked-practitioner-box">
        <img class="linked-practitioner-avatar" src="${escapeHTML(pImage)}" alt="${escapeHTML(pName)}" loading="lazy" />
        <div class="linked-practitioner-info">
          <span class="linked-label">Astuce partagée par</span>
          ${pId
            ? `<button class="linked-practitioner-link" type="button" data-detail-type="practitioner" data-detail-id="${escapeHTML(pId)}">${escapeHTML(pName)}</button>`
            : `<span class="linked-practitioner-name">${escapeHTML(pName)}</span>`
          }
        </div>
      </div>`
    : "";

  return `
    <article class="directory-card tip-card">
      <div class="card-media">
        <img src="${escapeHTML(tip.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(tip.imageAlt || tip.title)}" loading="lazy" />
        <span class="demo-badge">${escapeHTML(tip.categoryLabel)}</span>
      </div>
      <div class="card-body">
        <div class="card-meta"><span>${escapeHTML(tip.plantFocus)}</span><span>${tip.isDemo ? "Exemple" : "Conseil vérifié"}</span></div>
        <h3>${escapeHTML(tip.title)}</h3>
        <p>${escapeHTML(tip.summary)}</p>
        ${authorBadge}
        <button class="text-button" type="button" data-detail-type="tip" data-detail-id="${escapeHTML(tip.id)}">Lire l’astuce complète <span aria-hidden="true">→</span></button>
      </div>
    </article>`;
}

function updateCityOptions() {
  const selected = cityFilter.value;
  const cities = [...new Set(practitioners.map((person) => person.city).filter(Boolean))].sort((a, b) => a.localeCompare(b, "fr"));
  cityFilter.innerHTML = '<option value="all">Toutes les villes</option>' + cities
    .map((city) => `<option value="${escapeHTML(city)}">${escapeHTML(city)}</option>`).join("");
  cityFilter.value = cities.includes(selected) ? selected : "all";
}

function render() {
  const query = normalize(globalSearch.value);
  const selectedCity = cityFilter.value;

  const visibleProducts = products.filter((product) => {
    const categoryMatches = activeCategory === "all" || product.category === activeCategory;
    const queryMatches = !query || normalize(`${product.name} ${product.categoryLabel} ${product.description} ${product.practitionerName} ${product.practitionerCity}`).includes(query);
    return categoryMatches && queryMatches;
  });

  const visiblePractitioners = practitioners.filter((person) => {
    const cityMatches = selectedCity === "all" || person.city === selectedCity;
    const queryMatches = !query || normalize(`${person.name} ${person.specialty} ${person.city} ${person.region}`).includes(query);
    return cityMatches && queryMatches;
  });

  const visibleTips = tips.filter((tip) => {
    const queryMatches = !query || normalize(`${tip.title} ${tip.categoryLabel} ${tip.plantFocus} ${tip.summary} ${tip.practitionerName}`).includes(query);
    return queryMatches;
  });

  productList.innerHTML = visibleProducts.map(productCard).join("");
  practitionerList.innerHTML = visiblePractitioners.map(practitionerCard).join("");
  if (tipList) tipList.innerHTML = visibleTips.map(tipCard).join("");

  productCount.textContent = `${visibleProducts.length} fiche${visibleProducts.length === 1 ? "" : "s"}`;
  if (tipCount) tipCount.textContent = `${visibleTips.length} astuce${visibleTips.length === 1 ? "" : "s"}`;

  productEmpty.hidden = visibleProducts.length > 0;
  practitionerEmpty.hidden = visiblePractitioners.length > 0;
  if (tipEmpty) tipEmpty.hidden = visibleTips.length > 0;
}

function openDetails(type, id) {
  if (type === "product") {
    const entry = products.find((item) => item.id === id);
    if (!entry) return;
    const isDemo = Boolean(entry.isDemo);
    const linkedPractitioner = getLinkedPractitioner(entry);
    const pName = linkedPractitioner?.name || entry.practitionerName;
    const pCity = linkedPractitioner?.city || entry.practitionerCity;
    const pImage = linkedPractitioner?.image || entry.practitionerImage || "assets/waraka-apercu.jpg";
    const pId = linkedPractitioner?.id || entry.practitionerId;

    const whatsappText = encodeURIComponent(`Bonjour WARAKA, je souhaite avoir plus d'informations sur le produit "${entry.name}"${pName ? ` proposé par ${pName}` : ""}.`);

    const practitionerSection = pName ? `
      <div class="dialog-linked-card">
        <img src="${escapeHTML(pImage)}" alt="${escapeHTML(pName)}" />
        <div>
          <span class="linked-label">PRATICIEN RÉFÉRENT</span>
          <strong>${escapeHTML(pName)}</strong>
          ${pCity ? `<small>${escapeHTML(pCity)}</small>` : ""}
        </div>
        ${pId ? `<button class="button button-primary" type="button" data-detail-type="practitioner" data-detail-id="${escapeHTML(pId)}">Voir son profil</button>` : ""}
      </div>` : "";

    dialogContent.innerHTML = `
      <img class="dialog-image" src="${escapeHTML(entry.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(entry.imageAlt || entry.name)}" />
      <p class="eyebrow">FICHE PRODUIT · ${isDemo ? "DÉMONSTRATION" : "WARAKA"}</p>
      <h2 id="dialogTitle">${escapeHTML(entry.name)}</h2>
      <p class="dialog-summary">${escapeHTML(entry.categoryLabel)}${pName ? ` · ${escapeHTML(pName)}` : ""}</p>
      <p>${escapeHTML(entry.details || "")}</p>
      ${practitionerSection}
      <div class="dialog-actions">
        <a class="button button-primary" href="https://wa.me/${WHATSAPP_NUMBER}?text=${whatsappText}" target="_blank" rel="noreferrer">Demander des renseignements sur WhatsApp</a>
      </div>
      <p class="dialog-disclaimer">Cette fiche documentaire ne constitue ni une certification ni une recommandation médicale.</p>`;
    dialog.showModal();
    return;
  }

  if (type === "practitioner") {
    const entry = practitioners.find((item) => item.id === id);
    if (!entry) return;
    const isDemo = Boolean(entry.isDemo);
    const linkedProducts = products.filter((prod) => prod.practitionerId === entry.id || (prod.practitionerName && normalize(prod.practitionerName) === normalize(entry.name)));
    const linkedTips = tips.filter((tip) => tip.practitionerId === entry.id || (tip.practitionerName && normalize(tip.practitionerName) === normalize(entry.name)));

    const productsHtml = linkedProducts.length > 0 ? `
      <div class="dialog-related-section">
        <p class="eyebrow">PRODUITS ASSOCIÉS (${linkedProducts.length})</p>
        <div class="dialog-related-list">
          ${linkedProducts.map((prod) => `
            <button class="dialog-related-item" type="button" data-detail-type="product" data-detail-id="${escapeHTML(prod.id)}">
              <img src="${escapeHTML(prod.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(prod.name)}" />
              <span>
                <strong>${escapeHTML(prod.name)}</strong>
                <small>${escapeHTML(prod.categoryLabel)}</small>
              </span>
              <span aria-hidden="true">→</span>
            </button>`).join("")}
        </div>
      </div>` : "";

    const tipsHtml = linkedTips.length > 0 ? `
      <div class="dialog-related-section">
        <p class="eyebrow">ASTUCES PARTAGÉES (${linkedTips.length})</p>
        <div class="dialog-related-list">
          ${linkedTips.map((tip) => `
            <button class="dialog-related-item" type="button" data-detail-type="tip" data-detail-id="${escapeHTML(tip.id)}">
              <img src="${escapeHTML(tip.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(tip.title)}" />
              <span>
                <strong>${escapeHTML(tip.title)}</strong>
                <small>${escapeHTML(tip.plantFocus)}</small>
              </span>
              <span aria-hidden="true">→</span>
            </button>`).join("")}
        </div>
      </div>` : "";

    const whatsappText = encodeURIComponent(`Bonjour WARAKA, je souhaite entrer en contact avec ${entry.name} (${entry.city}).`);

    dialogContent.innerHTML = `
      <img class="dialog-image" src="${escapeHTML(entry.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(entry.imageAlt || entry.name)}" />
      <p class="eyebrow">PROFIL PRATICIEN · ${isDemo ? "DÉMONSTRATION" : "WARAKA"}</p>
      <h2 id="dialogTitle">${escapeHTML(entry.name)}</h2>
      <p class="dialog-summary">${escapeHTML(entry.specialty)} · ${escapeHTML(entry.city)}</p>
      <p>${escapeHTML(entry.details || "")}</p>
      ${productsHtml}
      ${tipsHtml}
      <div class="dialog-actions">
        <a class="button button-primary" href="https://wa.me/${WHATSAPP_NUMBER}?text=${whatsappText}" target="_blank" rel="noreferrer">Contacter via WARAKA (WhatsApp)</a>
      </div>
      <p class="dialog-disclaimer">Le référencement ne vaut pas autorisation d’exercice et ne constitue pas une recommandation médicale.</p>`;
    dialog.showModal();
    return;
  }

  if (type === "tip") {
    const entry = tips.find((item) => item.id === id);
    if (!entry) return;
    const linkedPractitioner = getLinkedPractitioner(entry);
    const pName = linkedPractitioner?.name || entry.practitionerName;
    const pImage = linkedPractitioner?.image || entry.practitionerImage || "assets/waraka-apercu.jpg";
    const pId = linkedPractitioner?.id || entry.practitionerId;
    const linkedProduct = entry.productId ? products.find((p) => p.id === entry.productId) : null;

    const practitionerSection = pName ? `
      <div class="dialog-linked-card">
        <img src="${escapeHTML(pImage)}" alt="${escapeHTML(pName)}" />
        <div>
          <span class="linked-label">PARTAGÉ PAR</span>
          <strong>${escapeHTML(pName)}</strong>
          <small>${escapeHTML(entry.plantFocus)}</small>
        </div>
        ${pId ? `<button class="button button-primary" type="button" data-detail-type="practitioner" data-detail-id="${escapeHTML(pId)}">Voir le praticien</button>` : ""}
      </div>` : "";

    const productSection = linkedProduct ? `
      <div class="dialog-related-section">
        <p class="eyebrow">PRODUIT ASSOCIÉ À CETTE ASTUCE</p>
        <div class="dialog-related-list">
          <button class="dialog-related-item" type="button" data-detail-type="product" data-detail-id="${escapeHTML(linkedProduct.id)}">
            <img src="${escapeHTML(linkedProduct.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(linkedProduct.name)}" />
            <span>
              <strong>${escapeHTML(linkedProduct.name)}</strong>
              <small>${escapeHTML(linkedProduct.categoryLabel)}</small>
            </span>
            <span aria-hidden="true">→</span>
          </button>
        </div>
      </div>` : "";

    dialogContent.innerHTML = `
      <img class="dialog-image" src="${escapeHTML(entry.image || "assets/waraka-apercu.jpg")}" alt="${escapeHTML(entry.imageAlt || entry.title)}" />
      <p class="eyebrow">ASTUCE &amp; SAVOIR · ${escapeHTML(entry.categoryLabel)}</p>
      <h2 id="dialogTitle">${escapeHTML(entry.title)}</h2>
      <p class="dialog-summary">${escapeHTML(entry.plantFocus)}</p>
      <p>${escapeHTML(entry.content || entry.summary)}</p>
      ${practitionerSection}
      ${productSection}
      <p class="dialog-disclaimer">Information éducative. Ne remplace pas l’avis d’un professionnel de santé.</p>`;
    dialog.showModal();
  }
}

document.querySelectorAll("[data-product-category]").forEach((button) => {
  button.addEventListener("click", () => {
    activeCategory = button.dataset.productCategory;
    document.querySelectorAll("[data-product-category]").forEach((chip) => {
      const active = chip === button;
      chip.classList.toggle("is-active", active);
      chip.setAttribute("aria-pressed", String(active));
    });
    render();
  });
});

function submitSearch() {
  render();
  document.querySelector("#produits").scrollIntoView({ behavior: "smooth", block: "start" });
}
document.querySelector("#searchButton").addEventListener("click", submitSearch);
globalSearch.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    event.preventDefault();
    submitSearch();
  }
});
globalSearch.addEventListener("input", render);
cityFilter.addEventListener("change", render);
document.addEventListener("click", (event) => {
  const trigger = event.target.closest("[data-detail-type]");
  if (trigger) openDetails(trigger.dataset.detailType, trigger.dataset.detailId);
});
document.querySelector("#dialogClose").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", (event) => {
  if (event.target === dialog) dialog.close();
});
document.querySelector("#contactWhatsapp").href =
  `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent("Bonjour Waraka, j'ai une question au sujet des produits, des praticiens référencés ou des astuces.")}`;

async function loadHomeCatalog() {
  if (!dataService?.isConfigured()) {
    updateCityOptions();
    render();
    return;
  }
  document.querySelector("#productIntroNote").textContent = "Consultez les fiches produits publiées et le praticien associé à chacune.";
  document.querySelector("#practitionerIntroNote").textContent = "Découvrez les profils publiés et les informations professionnelles communiquées à WARAKA.";
  if (document.querySelector("#tipIntroNote")) {
    document.querySelector("#tipIntroNote").textContent = "Conseils pratiques et savoirs botaniques partagés par nos praticiens référencés.";
  }
  document.querySelector("#footerDemoDisclaimer").textContent = "Les contenus publiés par WARAKA ne constituent pas des recommandations de santé.";

  const results = await Promise.allSettled([
    dataService.listProducts(),
    dataService.listPractitioners(),
    dataService.listTips(),
  ]);

  if (results[0].status === "fulfilled") products = results[0].value;
  else {
    console.error("Impossible de charger les produits WARAKA.", results[0].reason);
    products = [];
  }
  if (results[1].status === "fulfilled") practitioners = results[1].value;
  else {
    console.error("Impossible de charger les praticiens WARAKA.", results[1].reason);
    practitioners = [];
  }
  if (results[2].status === "fulfilled" && Array.isArray(results[2].value)) {
    tips = results[2].value;
  } else {
    // Fallback to demo tips if table 'tips' hasn't been created in Supabase yet
    console.warn("Table 'tips' non chargée depuis Supabase, utilisation des astuces locales.", results[2].reason);
  }

  updateCityOptions();
  render();
}

loadHomeCatalog();
