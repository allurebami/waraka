# WARAKA

WARAKA est une plateforme en HTML, CSS et JavaScript consacrée aux produits traditionnels, aux praticiens référencés et aux astuces botaniques au Cameroun. Les pages publiques peuvent lire le catalogue, l’annuaire et les conseils depuis Supabase.

## Pages

- `index.html` : accueil, recherche globale et aperçu des trois répertoires (Produits, Praticiens, Astuces).
- `produits.html` : catalogue des produits, recherche, filtres et fiches détaillées liées au praticien référent.
- `praticiens.html` : répertoire des praticiens, recherche par profil ou ville, avec affichage de leurs produits et astuces associés.
- `astuces.html` : carnet pratique d'astuces et usages des plantes partagés par les praticiens référencés.

Sans configuration Supabase, les pages utilisent les données de démonstration. Une fois Supabase configuré, elles n’affichent que les produits approuvés, les praticiens publiés et les astuces validées.

## Connecter Supabase

1. Dans le tableau de bord Supabase, ouvre **SQL Editor** et exécute `supabase/schema.sql` (qui crée les tables `practitioners`, `products` et `tips`).
2. Dans les paramètres API du projet, copie le **Project URL** et la clé **publishable** (ou l’ancienne clé `anon`).
3. Renseigne ces deux valeurs dans `supabase-config.js` (`url` et `publishableKey`), puis redéploie le site.
4. Ajoute les fiches dans les tables `practitioners`, `products` (en reliant `practitioner_id`) et `tips` (en reliant `practitioner_id` et optionnellement `product_id`).

## Lancer en local

Ouvrir `index.html` dans un navigateur ou servir le dossier avec un serveur HTTP statique. Le site peut être hébergé sur Vercel ou GitHub Pages.
